#include<iostream>
#include<string>
#include<time.h>

using namespace std;

const int MAXNO = 20;

void populateArr(int **arr,int mRw, int nCl);
void prArr(int **arr, int mRw, int nCl);
void prArr(int *arr,int aSz);

int main()
{
    srand(time(0));
    int mRows, nCols;
    cout <<"Enter the no of rows :  ";
    cin >> mRows;
    cout <<"Enter the no of cols :  ";
    cin >> nCols;
    int **arr;
    arr = new int*[mRows];
    for(int i = 0; i < mRows; i++)
    {
        arr[i] = new int[nCols];
    }
    populateArr(arr, mRows, nCols);
    prArr(arr, mRows, nCols);
    return 0;
}

void populateArr(int **arr, int mRw, int nCl)
{
    int mRows = mRw;
    int nCols = nCl;
     for(int i = 0; i < mRows; i++)
    {
        for(int j = 0; j < nCols; j++)
        {
            int theVal = rand()% MAXNO + 1;
            arr[i][j] = theVal;
        }
    }
}

void prArr(int **arr, int mRw, int nCl)
{
    int mRows = mRw;
    int nCols = nCl;
    for(int i = 0; i < mRows; i++)
    {
        for(int j = 0; j < nCols; j++)
        {
            cout << arr[i][j] << "\t"; //new int[nCols];
        }
        cout << "\n";
    }
}
